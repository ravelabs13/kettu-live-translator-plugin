# Kettu Translate v1.3.1 — source package

This package contains the editable source and build files corresponding to the device-tested `index.js` with SHA-256 `331bc56e2d45fbca15f3fc9573ebc88d33a206ec5125fe7e28e109bd80a9a584`.

RaveLabs' own source files are offered under MPL-2.0; see `LICENSE`. The generated runtime includes `@swc/helpers` 0.5.23 under Apache-2.0; see `THIRD_PARTY_NOTICES.md` and `LICENSES/Apache-2.0.txt`.

With compatible Node.js and npm installed, run `npm ci`, `npm run build`, then `npm test`. The lockfile fixes the dependency versions used for this release.
